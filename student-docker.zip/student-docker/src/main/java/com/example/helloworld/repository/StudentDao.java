package com.example.helloworld.repository;

import org.springframework.data.repository.CrudRepository;
import com.example.helloworld.entity.Student;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentDao extends CrudRepository<Student, Integer>{

}
