package com.example.helloworld.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.helloworld.entity.Student;
import com.example.helloworld.repository.StudentDao;
import com.example.helloworld.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentDao studentDao;
	
	@Override
	public String saveStudent(Student student) {
		studentDao.save(student);
		return "saved successfully";
	}

	@Override
	public Iterable<Student> getAllStudents() {
		return studentDao.findAll();
	}

}
